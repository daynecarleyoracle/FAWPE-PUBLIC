
[ -f ~/current-state-backup-name ] || { echo Exiting due to file current-state-backup-name not found - code rc $? ; return 54; }

[ $( cat ~/current-state-backup-name |wc -l ) -eq 1 ] || { echo Exiting due to file current-state-backup-name not having just one line ; return 55; }

[ $(cat ~/current-state-backup-name |grep current ) >null ] || { echo Exiting due to incorrect contents of file current-state-backup-name ; return 56; }

backup_name=$(cat ~/current-state-backup-name)

echo "Testing $backup_name"
unzip -t $backup_name 1>null || { echo Exiting due to failure rc $? testing $backup_name; return 57; }

echo "Removing the modified fawpe folder "
cd; rm -r fawpe || { echo Exiting due to failure rc $? removing folder fawpe; return 52; } 

echo "Restoring fawpe from $backup_name"
unzip $backup_name >null || { echo Exiting due to unzip failure rc $? of $backup_name; return 53; }
echo "Restore complete"
