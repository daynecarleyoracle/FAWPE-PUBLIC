
# Begin fawpe-access-internal.sh

function restore-prior-state ()
{
  # Restore Prior state
  echo Restoring Prior state

  # Extract the Restore Script
  #echo Extracting the Restore Script
  #cd $HOME; unzip -j $HOME/fawpe-access-internal.zip fawpe/fawpe-restore.sh -d $HOME;

   [ -f ~/current-state-backup-name ] || { echo Exiting due to file current-state-backup-name not found - code rc $? ; return 54; }
   
   [ $( cat ~/current-state-backup-name |wc -l ) -eq 1 ] || { echo Exiting due to file current-state-backup-name not having just one line ; return 55; }
   
   [ $(cat ~/current-state-backup-name |grep current ) >null ] || { echo Exiting due to incorrect contents of file current-state-backup-name ; return 56; }
   
   backup_name=$(cat ~/current-state-backup-name)
   
   echo "Testing $backup_name"
   unzip -t $backup_name 1>null || { echo Exiting due to failure rc $? testing $backup_name; return 57; }
   
   echo "Removing the modified fawpe folder "
   cd; rm -r fawpe || { echo Exiting due to failure rc $? removing folder fawpe; return 52; }
   
   echo "Restoring fawpe from $backup_name"
   unzip $backup_name >null || { echo Exiting due to unzip failure rc $? of $backup_name; return 53; }
   echo "Restore complete"
   
}

function transform-variables ()
{
  # Transform variables
  echo Transforming Variables
  cd ~/fawpe/main/tf-main
  source ~/fawpe/main/access-internal.prof*
  source ~/fawpe/main/.access-internal.prof*

# Get list of existing variables
  cat variables.tf |cut -f 1 -d { >/tmp/existing-variables

# Get variables that do not currently exist and append them
  env |grep TF_ |sed 's/TF_VAR_/variable /; s/=/ {default = "/; s/$/"}/' |grep -v -f /tmp/existing-variables >>variables.tf

# Sort the variables by name
  mv variables.tf /tmp/tmpvars; cat /tmp/tmpvars |sort >variables.tf
}


function transform-outputs ()
{
  # Transform outputs
  echo Transforming outputs
  cd ~/fawpe/main/tf-main

# Get list of existing outputs
cat outputs.tf |grep -v ^# |cut -f 2 -d \" >/tmp/existing-outputs
echo "{{" >>/tmp/existing-outputs

# Get outputs that do not currently exist and append them
  cat ~/fawpe/main/access-internal-documents/access-internal-outputs.txt |grep -v ^# |grep  -v -f /tmp/existing-outputs>>outputs.tf

# Sort the outputs by name
  mv outputs.tf /tmp/tmpoutputs; cat /tmp/tmpoutputs |sort >outputs.tf
}


function build ()
{
echo Build;

# Initilize terraform
cd ~/fawpe/main/tf-main
echo Running terraform INIT
terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

# Apply terraform
echo Running terraform APPLY
terraform apply || { echo Exiting due to terraform apply rc $?; exit 4; }
#terraform apply

}

function plan ()
{
echo Plan;

#transform-variables
echo Transforming Variables
transform-variables

#transform-outputs
echo Transforming Outputs
transform-outputs

# Initilize terraform
cd ~/fawpe/main/tf-main
echo Running terraform INIT
terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

# Plan terraform
echo Running terraform PLAN
terraform plan || { echo Exiting due to terraform plan rc $?; exit 3; }
}

function output ()
{
echo output;
# Initilize terraform
cd ~/fawpe/main/tf-main
echo Running terraform INIT
terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

#  terraform output
echo Running terraform OUTPUT
terraform output || { echo Exiting due to terraform output rc $?; exit 7; }
}

function show ()
{
echo show;
# Initilize terraform
cd ~/fawpe/main/tf-main
echo Running terraform INIT
terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

#  terraform show
echo Running terraform SHOW
terraform show || { echo Exiting due to terraform show rc $?; exit 8; }
}

function delete ()
{
echo Delete;

   cd; restore-prior-state

# Initilize terraform
   cd ~/fawpe/main/tf-main
   echo Running terraform INIT
   terraform init || { echo Exiting due to terraform init rc $?; exit 62; }
#   
   echo Running terraform plan
   terraform plan || { echo Exiting due to terraform plan rc $?; exit 66; }
#   
   echo Running terraform apply
   terraform apply || { echo Exiting due to terraform apply rc $?; exit 67; }
}

#Begin

source ~/fawpe/main/*.profile
source ~/fawpe/main/.*.profile

#Expecting process to be first parameter

export process=$1

test $process || { echo no process as frst parameter; exit; }


if [ $process = api-files ]; then api-files \
         && echo $process completed || echo $process returned $?;
elif [ $process = build ]; then build \
         && echo $process completed || echo $process returned $?;
elif [ $process = plan ]; then plan \
         && echo $process completed || echo $process returned $?;
elif [ $process = delete ]; then delete \
         && echo $process completed || echo $process returned $?;
elif [ $process = show ]; then show \
         && echo $process completed || echo $process returned $?;
elif [ $process = output ]; then output \
         && echo $process completed || echo $process returned $?;
else echo Exiting - Unknown process;
fi
