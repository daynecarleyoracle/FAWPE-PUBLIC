now=$(date +"%Y-%m-%d-%T" |sed "s/:/-/g")
backup_name=current-state-${now}.zip
echo "backing up fawpe to $backup_name"
echo $backup_name >~/current-state-backup-name
cd; zip -r $backup_name fawpe >null || { echo Exiting due to zip failure rc $? of fawpe directory; exit 42; }
echo "Backup complete"
