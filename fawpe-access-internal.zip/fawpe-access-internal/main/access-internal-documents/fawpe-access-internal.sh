
# Begin fawpe-access-internal.sh

function backup ()
{
   #Expecting state to be the first parameter 

   export state=$1
   test $state || { echo Exiting - no state as first parameter; exit 72; }
   
   now=$(date +"%Y-%m-%d-%T" |sed "s/:/-/g")
   backup_name=$state-state-${now}.zip
   echo "backing up to $backup_name"
   echo $backup_name >~/$state-state-backup-name
   cd; zip -r $backup_name fawpe-working >null || { echo Exiting due to zip failure rc $? of fawpe-working directory; exit 42; }
   echo "Backup of $state complete"
}


function restore-prior-state ()
{
  # Restore Prior state
  echo Restoring Prior state

  cd ~/fawpe-working/resources
  rm *.tf
  unzip -jo ~/$(cat ~/prior-state-backup-name) fawpe-working/resources/*.tf

  echo "Restore complete"
   
}

function transform-variables ()
{
  # Check if access-internal has been planned before
  $(cat $HOME/fawpe-working/resources/outputs.tf|grep windows19_id >null)
  [ $? == 0 ] && { backup modified; restore-prior-state; }

##[ $(cat $HOME/fawpe-working/resources/outputs.tf |grep windows19_id ) ] && { backup modified; restore-prior-state; }
 ## [ $(cat $HOME/fawpe-working/resources/outputs.tf |grep windows19_id ) ] && { backup modified; restore-prior-state; }
  ##  [ -f $HOME/fawpe-working/resources/windows-compute.tf ] && { backup modified; restore-prior-state; }

  # Transform variables
  echo Transforming Variables
  ## touch access-internal-modified
  source ~/fawpe-access-internal/main/access-internal.prof*
  source ~/fawpe-access-internal/main/.access-internal.prof*

# Get list of original variables
  cat variables.tf |grep -v -f /tmp/new-variables |cut -f 1 -d { >/tmp/original-variables
echo Original
cat /tmp/original-variables

echo TF variables
env |grep TF_

# Get variables that do not currently exist and append them
  env |grep TF_ |sed 's/TF_VAR_/variable /; s/=/ {default = "/; s/$/"}/' |grep -v -f /tmp/original-variables >>variables.tf

echo New variables
cat variables.tf

# Sort the variables by name
  mv variables.tf /tmp/tmpvars; cat /tmp/tmpvars |sort >variables.tf
}


function transform-outputs ()
{
  # Transform outputs
  echo Transforming outputs
  cd ~/fawpe-working/resources

# Get list of existing outputs
   cat outputs.tf |grep -v ^# |cut -f 2 -d \" >/tmp/existing-outputs
   echo "{{" >>/tmp/existing-outputs

# Get outputs that do not currently exist and append them
  cat ~/fawpe-access-internal/main/access-internal-documents/access-internal-outputs.txt |grep -v ^# |grep  -v -f /tmp/existing-outputs >>outputs.tf

# Sort the outputs by name
  mv outputs.tf /tmp/tmpoutputs; cat /tmp/tmpoutputs |sort >outputs.tf
}


function build ()
{
   echo Build;

   # Initilize terraform
   cd ~/fawpe-working/resources
   echo Running terraform INIT
   terraform init || { echo Exiting due to terraform init rc $?; exit 2; }
   
   # Apply terraform
   echo Running terraform APPLY
   terraform apply || { echo Exiting due to terraform apply rc $?; exit 4; }

   # Backup applied state
   echo Backing up applied state
   backup access-internal
   
}

function plan ()
{
   echo Plan;
   
   #transform-variables
   echo Transforming Variables
   transform-variables
   
   #transform-outputs
   echo Transforming Outputs
   transform-outputs

   # Add resources
   echo Adding Resources
   unzip -juo ~/fawpe-access-internal.zip fawpe-access-internal/main/tf-main/* -d ~/fawpe-working/resources

   # Add modules
   echo Adding modules
   cd ~/fawpe-access-internal/modules; unzip -uo * -d ~/fawpe-working/modules
   
   # Remove lock file for reruns in case it has expired
   cd ~/fawpe-working/resources
   echo Removing lock file
   [ -f .terraform.lock.hcl ] && rm -f .terraform.lock.hcl

   # Initilize terraform
   cd ~/fawpe-working/resources
   echo Running terraform INIT
   terraform init || { echo Exiting due to terraform init rc $?; exit 2; }
   
   # Plan terraform
   echo Running terraform PLAN
   terraform plan || { echo Exiting due to terraform plan rc $?; exit 3; }
}

function output ()
{
   echo output;
   # Initilize terraform
   cd ~/fawpe-working/resources
   echo Running terraform INIT
   terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

   #  terraform output
   echo Running terraform OUTPUT
   terraform output || { echo Exiting due to terraform output rc $?; exit 7; }
}

function show ()
{
   echo show;
   # Initilize terraform
   cd ~/fawpe-working/resources
   echo Running terraform INIT
   terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

#  terraform show
   echo Running terraform SHOW
   terraform show || { echo Exiting due to terraform show rc $?; exit 8; }
}

function delete ()
{
   echo Delete;

   cd; restore-prior-state

   # Initilize terraform
   cd ~/fawpe-working/resources
   echo Running terraform INIT
   terraform init || { echo Exiting due to terraform init rc $?; exit 62; }
   #   
   echo Running terraform plan
   terraform plan || { echo Exiting due to terraform plan rc $?; exit 66; }
   #   
   echo Running terraform apply
   terraform apply || { echo Exiting due to terraform apply rc $?; exit 67; }
}

#Begin

#Expecting process to be the first parameter
#Expecting state to be the second parameter for backups 

export process=$1
test $process || { echo no process as first parameter; exit; }

# Check if access-internal has been planned
  [ -f $HOME/fawpe-working/resources/windows-compute.tf ] || backup prior

#if [ $process = backup ]; then backup $2 \
#         && echo $process completed || echo $process returned $?;
#     exit;
#fi

source ~/fawpe-access-internal/main/*.profile
source ~/fawpe-access-internal/main/.*.profile

if [ $process = build ]; then build \
         && echo $process completed || echo $process returned $?;
elif [ $process = plan ]; then plan \
         && echo $process completed || echo $process returned $?;
elif [ $process = delete ]; then delete \
         && echo $process completed || echo $process returned $?;
elif [ $process = show ]; then show \
         && echo $process completed || echo $process returned $?;
else echo Exiting - Unknown process;
fi
