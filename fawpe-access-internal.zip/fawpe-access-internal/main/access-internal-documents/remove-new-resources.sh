rm ig-only-route-table-module.tf
rm internet-gateway.tf
rm public-int-subnet-module.tf
rm windows-compute.tf

