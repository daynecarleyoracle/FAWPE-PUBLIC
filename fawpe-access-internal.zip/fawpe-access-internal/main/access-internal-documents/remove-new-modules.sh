rm -r oci_local_route_table

