
# Begin fawpe-prepare.sh

function transform-variables ()
{
  # Transform variables
  echo Transforming Variables
  cd ~/fawpe/main/tf-main
  source ~/fawpe/main/*.prof*
  source ~/fawpe/main/.*.prof*
  [ -f variables.tf ] && rm variables.tf
  env |grep TF_ | sed 's/TF_VAR_/variable /; s/=/ {default = "/; s/$/"}/' >>variables.tf
}

function api-files ()
{
echo API files;
# Move the api key files
cd;
mkdir ~/.oci 2>null

test -f ~/fawpe-config.txt || { echo "Exiting - file fawpe-config.txt not found"; return 12; }
grep -v key_file ~/fawpe-config.txt >~/.oci/config

[ $(ls *.pem |wc -l) == 1 ] || { echo "Exiting - the number of .pem files must be 1"; return 12; }
mv ~/*.pem ~/.oci/$TF_VAR_api_key_name || { echo "Exiting - failure moving $TF_VAR_api_key_name "; return 14; }

chmod 600 ~/.oci/$TF_VAR_api_key_name
}

function plan ()
{
echo Plan;
cd ~/fawpe/main/tf-main

# Initilize terraform
echo Running terraform init
terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

# Plan terraform
echo Running terraform plan
terraform plan || { echo Exiting due to terraform plan rc $?; exit 3; }
}

function build ()
{
echo Build;

# Initilize terraform
cd ~/fawpe/main/tf-main
echo Running terraform init
terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

# Apply terraform
echo Running terraform apply
terraform apply || { echo Exiting due to terraform apply rc $?; exit 4; }
#terraform apply

}

function output ()
{
echo output;
# Initilize terraform
cd ~/fawpe/main/tf-main
echo Running terraform init
terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

#  terraform output
echo Running terraform output
terraform output || { echo Exiting due to terraform output rc $?; exit 7; }
}

function show ()
{
echo show;
# Initilize terraform
cd ~/fawpe/main/tf-main
echo Running terraform init
terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

#  terraform show
echo Running terraform show
terraform show || { echo Exiting due to terraform show rc $?; exit 8; }
}

function destroy ()
{
echo Destroy;
# Initilize terraform
cd ~/fawpe/main/tf-main
echo Running terraform init
terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

#  terraform destroy
echo Running terraform destroy
terraform destroy || { echo Exiting due to terraform destroy rc $?; exit 6; }
}

#Begin

#Expecting process to be first parameter

export process=$1
test $process || { echo no process as frst parameter; exit; }

#Expecting there NOT to be a variables.tf in the zip file. The process below creates it.
[ -f ~/fawpe/main/tf-main/variables.tf ] || transform-variables


if [ $process = api-files ]; then api-files \
         && echo $process completed || echo $process returned $?;
elif [ $process = build ]; then build \
         && echo $process completed || echo $process returned $?;
elif [ $process = plan ]; then plan \
         && echo $process completed || echo $process returned $?;
elif [ $process = destroy ]; then destroy \
         && echo $process completed || echo $process returned $?;
elif [ $process = show ]; then show \
         && echo $process completed || echo $process returned $?;
elif [ $process = output ]; then output \
         && echo $process completed || echo $process returned $?;
else echo Exiting - Unknown process;
fi
