# Begin fawpe-prepare.sh
  
function destroy ()
{
    [ -d $WORKSPACE ] || { echo "Nothing to destroy"; return; }
    echo Destroying $WORKSPACE_STATE_NAME WORKSPACE
    cd $WORKSPACE; terraform init

    echo Running terraform DESTROY
    echo Enter \"yes\" when prompted
    terraform destroy
    export RETURN_CODE=$?

    [ $RETURN_CODE -gt 1 ] && { echo Exiting due to terraform DESTROY rc $?; exit 5; }
    
    echo " "

    [ $RETURN_CODE -eq 1 ] && { echo Terraform DESTROY Halted.; return; }

    [ $RETURN_CODE -eq 0 ] && echo Terraform DESTROY Completed.
    
    cd;
    rm -r $WORKSPACE_HOME/modules $WORKSPACE_HOME/resources $WORKSPACE_HOME/states
    rm -r ~/.oci
    cat ~/fawpe-PREPARE/documents/PREPARE-env-vars.sh | grep -v TF_VAR_compartment_id >/tmp/PREPARE-env-vars.sh
    mv /tmp/PREPARE-env-vars.sh ~/fawpe-PREPARE/documents/PREPARE-env-vars.sh 
}

function set-prepare-home-variables ()
{
  function check-public-key
  {
    [ -f $WORKSPACE/$TF_VAR_PUBLIC_KEY_NAME ] || touch $WORKSPACE/$TF_VAR_PUBLIC_KEY_NAME
  }
  function check-oci-dir
  {
    [ -d ~/.oci ] || mkdir ~/.oci
  }

  function check-compartment-id ()
  {
    cat ~/fawpe-PREPARE/documents/PREPARE-env-vars.sh | grep TF_VAR_compartment_id >null && { echo TF_VAR_compartment_id exists; return; }

    echo " "
      read -p "Enter your FAW compartment id and press enter: " comp_id
      echo export TF_VAR_compartment_id=$comp_id >>~/fawpe-PREPARE/documents/PREPARE-env-vars.sh
  }

# BEGIN set-prepare-home-variables
  check-compartment-id
  source ~/fawpe-PREPARE/documents/PREPARE-env-vars.sh
  check-oci-dir
  check-public-key
}

function show ()
{
  echo Running terraform SHOW
  init
  terraform show || { echo Exiting due to terraform SHOW rc $?; exit 6; }
}

function init ()
{
  echo " "
  echo Running terraform INIT

  [ -d $WORKSPACE ] || { echo Exiting - No workspace $WORKSPACE; exit 50; }

  cd $WORKSPACE
  [ -f .*lock* ] && { echo removing lock $(ls -a .*lock*); rm .*lock*; }

  terraform init || { echo Exiting due to terraform INIT rc $?; exit 3; }
  echo " "
  echo Running terraform REFRESH
  terraform refresh || { echo Exiting due to terraform REFRESH rc $?; exit 31; }
}

bash ~/fawpe-PREPARE/documents/PREPARE-env-vars.sh

  
function deploy ()
{
  function create-state ()
  {

    function create_authentication ()
    {

      function check-api-key ()
      {
        echo " ";  echo checking API key 
        cd $WORKSPACE        
        init

    #    export TF_VAR_identity_provider_name=$(terraform output identity_provider_name |sed 's/"//g')
    #    export TF_VAR_full_user_name=${TF_VAR_identity_provider_name,,}/$TF_VAR_USER_NAME
        terraform output fawpe_api_key_fingerprint || return 5 && { echo api-key exists; return; } 
      }

      function create-api-key ()
      {
        function begin-oci-config ()
        {
          echo tenancy=$OCI_TENANCY >~/.oci/config
          echo user=$(terraform output user_id) >>~/.oci/config
        }

        function complete-oci-config ()
        {
          echo fingerprint=$(terraform output fawpe_api_key_fingerprint) >>~/.oci/config
        }

       # Begin create-api-key

        export num_api_keys=$(terraform output -json api_keys|jq .|grep -v "\[" |grep -v "\]" |wc -l)
        [ $num_api_keys -eq 3 ] && { echo "Exiting - Three existing api-keys. Please delete one manually"; exit 65; }

        begin-oci-config

        echo " ";  echo creating api-key pair
        openssl genrsa -out ~/.oci/$TF_VAR_PRIVATE_KEY_NAME 2048
        openssl rsa -pubout -in ~/.oci/$TF_VAR_PRIVATE_KEY_NAME -out ~/.oci/$TF_VAR_PUBLIC_KEY_NAME
        cp -p ~/.oci/$TF_VAR_PUBLIC_KEY_NAME $WORKSPACE

        echo " ";  echo creating oci api key 
        terraform apply -target=oci_identity_api_key.api_key ||  { echo Exiting due to api key failure rc $?; exit 131; }
        echo " ";  echo finished creating api key

        complete-oci-config
      }

   # Begin create_authentication
      check-api-key && return

      echo " ";  echo creating authentication
      create-api-key
      echo " ";  echo finished creating authentication
    }

    function remove-resources ()
    {
      [ -d $WORKSPACE_HOME/modules ] && rm -r $WORKSPACE_HOME/modules
      [ -d $WORKSPACE_HOME/resources ] && rm -r $WORKSPACE_HOME/resources/*.tf
    }

    function create-resources ()
    {   
      echo creating resources

      cd $WORKSPACE_HOME
      unzip -o $PREPARE_SOURCE_ZIP_NAME 
    }

    function set-state ()
    {
      cd $WORKSPACE_HOME
      [ -d states ] || mkdir states
      echo "Setting $PREPARE_STATE_NAME state"
      echo $PREPARE_STATE_NAME >states/state-name.txt
      echo "NULL" >states/prior-state-name.txt
    }

#Begin CREATE-STATE
    echo creating state
    set-state
    remove-resources
    create-resources
    create_authentication
  }

  function plan ()
  {
    echo Running terraform PLAN
    cd $WORKSPACE; terraform plan || { echo Exiting due to terraform PLAN rc $?; exit 4; }
    echo " "
    read -p "Review the plan and enter yes to continue: " plan_var
  }
  
  function apply ()
  {
    function save-state ()
    {
      echo saving state
      cd $WORKSPACE_HOME
      export SAVED_STATE_ZIP_NAME=$HOME/$WORKSPACE_STATE_NAME-saved-state.zip
      [ -f $SAVED_STATE_ZIP_NAME ] && rm $SAVED_STATE_ZIP_NAME
      zip -r $SAVED_STATE_ZIP_NAME *
      cd;
    }
  # Begin apply

    echo " "
    [ $plan_var = "yes" -o $plan_var = "YES" ] || { echo "You have stopped the Deployment."; return; }

    echo Running terraform APPLY
    echo Enter \"yes\" when prompted
    cd $WORKSPACE; terraform apply
    export RETURN_CODE=$?

    [ $RETURN_CODE -gt 1 ] && { echo Exiting due to terraform APPLY rc $?; exit 5; }
    
    echo " "
    echo Terraform Apply Completed.

    [ $RETURN_CODE -eq 0 ] && save-state

  }

  

#BEGIN deploy
  create-state
  init
  plan
  apply
}

#Begin Main

echo USING REGION $OCI_REGION
cd; set-prepare-home-variables

echo Expecting process to be first parameter
export process=$1
test $process || { echo no process as frst parameter; exit; }

if [ $process = deploy ]; then deploy \
         && echo $process completed || echo $process returned $?;
elif [ $process = show ]; then show \
         && echo $process completed || echo $process returned $?;
elif [ $process = destroy ]; then destroy \
         && echo $process completed || echo $process returned $?;
else echo Exiting - Unknown process;
fi
