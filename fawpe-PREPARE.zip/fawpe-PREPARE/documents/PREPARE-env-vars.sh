  echo Preparing Environment Variables
  export now=$(date +"%Y-%m-%d-%T")
  export TF_VAR_PRIVATE_KEY_NAME="oci_api_key.pem"
  export TF_VAR_PUBLIC_KEY_NAME="oci_api_key_public.pem"
  export TF_VAR_HOME=$HOME
  export TF_VAR_TENANCY=$OCI_TENANCY
  export TF_VAR_faw_region=$OCI_REGION
  export TF_VAR_USER_NAME=$(echo $OCI_CS_USER_OCID |cut -f 2 -d "/" )
  export TF_VAR_oci_identity_provider_id=$(echo $OCI_CS_USER_OCID |cut -f 1 -d "/" )
    export INITIAL_STATE_NAME="INITIAL"
    export PREPARE_STATE_NAME="PREPARE"
    export PUBLIC_STATE_NAME="PUBLIC"
    export PRIVATE_STATE_NAME="PRIVATE"
    export WORKSPACE_NAME=fawpe-WORKSPACE
    export INITIAL_NAME=fawpe-$INITIAL_STATE_NAME
    export PREPARE_NAME=fawpe-$PREPARE_STATE_NAME
    export PUBLIC_NAME=fawpe-$PUBLIC_STATE_NAME
    export PRIVATE_NAME=fawpe-$PRIVATE_STATE_NAME
    export WORKSPACE_HOME=$HOME/$WORKSPACE_NAME
    [ -d $WORKSPACE_HOME ] || mkdir $WORKSPACE_HOME
    export INITIAL_HOME=$HOME/$INITIAL_NAME
    export PREPARE_HOME=$HOME/$PREPARE_NAME
    export PUBLIC_HOME=$HOME/$PUBLIC_NAME
    export PRIVATE_HOME=$HOME/$PRIVATE_NAME
    export INITIAL_SOURCE_ZIP_NAME=$INITIAL_HOME/$INITIAL_NAME-source.zip
    export PREPARE_SOURCE_ZIP_NAME=$PREPARE_HOME/$PREPARE_NAME-source.zip
    [ -f $PREPARE_SOURCE_ZIP_NAME ] || { echo "Exiting - no file $PREPARE_SOURCE_ZIP_NAME"; exit 81; }
    export PUBLIC_SOURCE_ZIP_NAME=$PUBLIC_HOME/$PUBLIC_NAME-source.zip
    export PRIVATE_SOURCE_ZIP_NAME=$PRIVATE_HOME/$PRIVATE_NAME-source.zip
    export WORKSPACE=$WORKSPACE_HOME/resources
    export WORKSPACE_STATE_NAME=$PREPARE_STATE_NAME
    [ -d $PREPARE_HOME ] || { echo "Exiting - no PREPARE HOME"; exit 8; }
    export PREPARE_SOURCE_ZIP_NAME=$PREPARE_HOME/$PREPARE_NAME-source.zip
