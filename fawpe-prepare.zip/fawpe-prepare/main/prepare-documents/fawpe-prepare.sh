
# Begin fawpe-prepare.sh

function create-working-directory ()
{
mkdir -p ~/fawpe-working/resources || { echo "Exiting - error creating working directory"; return 100; }
mkdir ~/fawpe-working/modules || { echo "Exiting - error creating working directory"; return 100; }
cp -p ~/fawpe-prepare/main/tf-main/* ~/fawpe-working/resources || { echo "Exiting - error copying resources"; return 100; }
cp -pr ~/fawpe-prepare/modules/* ~/fawpe-working/modules  || { echo "Exiting - error copying modules"; return 100; }
}

function transform-variables ()
{
  # Transform variables
  echo Transforming Variables
  cd ~/fawpe-working/resources  || { echo "Exiting - error changing to working directory"; return 200; }
  source ~/fawpe-prepare/main/*.prof* || { echo "Exiting - error sourcing profile"; return 200; }
  source ~/fawpe-prepare/main/.*.prof* || { echo "Exiting - error sourcing .profile"; return 200; }
  [ -f variables.tf ] && rm variables.tf
  env |grep TF_ | sed 's/TF_VAR_/variable /; s/=/ {default = "/; s/$/"}/' >variables.tf
}

function api-files ()
{
echo API files;
# Move the api key files
cd;
mkdir ~/.oci 2>null

test -f ~/fawpe-config.txt || { echo "Exiting - file fawpe-config.txt not found"; return 12; }
grep -v key_file ~/fawpe-config.txt >~/.oci/config

[ $(ls *.pem |wc -l) == 1 ] || { echo "Exiting - the number of .pem files must be 1"; return 12; }
mv ~/*.pem ~/.oci/$TF_VAR_api_key_name || { echo "Exiting - failure moving $TF_VAR_api_key_name "; return 14; }

chmod 600 ~/.oci/$TF_VAR_api_key_name
}

function plan ()
{
echo Plan;
cd ~/fawpe-working/resources || { echo "Exiting - no working directory code $? "; return 212; }


   # Remove lock file for reruns in case it has expired
   echo Removing lock file
   [ -f .terraform.lock.hcl ] && rm -f .terraform.lock.hcl

# Initilize terraform
echo Running terraform init
terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

# Plan terraform
echo Running terraform plan
terraform plan || { echo Exiting due to terraform plan rc $?; exit 3; }
}

function build ()
{
echo Build;

# Initilize terraform
cd ~/fawpe-working/resources
echo Running terraform init
terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

# Apply terraform
echo Running terraform apply
terraform apply || { echo Exiting due to terraform apply rc $?; exit 4; }
#terraform apply

}

function output ()
{
echo output;
# Initilize terraform
cd ~/fawpe-working/resources
echo Running terraform init
terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

#  terraform output
echo Running terraform output
terraform output || { echo Exiting due to terraform output rc $?; exit 7; }
}

function show ()
{
echo show;
# Initilize terraform
cd ~/fawpe-working/resources
echo Running terraform init
terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

#  terraform show
echo Running terraform show
terraform show || { echo Exiting due to terraform show rc $?; exit 8; }
}

function destroy ()
{
echo Destroy;
# Initilize terraform
cd ~/fawpe-working/resources
echo Running terraform init
terraform init || { echo Exiting due to terraform init rc $?; exit 2; }

#  terraform destroy
echo Running terraform destroy
terraform destroy || { echo Exiting due to terraform destroy rc $?; exit 6; }

# Remove working directory
echo Removing working directory
[ -d ~/fawpe-working ] && rm -r ~/fawpe-working
}

#Begin

#Expecting process to be first parameter

export process=$1
test $process || { echo no process as frst parameter; exit; }

#On the first run create the fawpe-working directory and populate them
[ -d ~/fawpe-working ] || create-working-directory

# Transform variables on first run and in case of change
transform-variables

if [ $process = api-files ]; then api-files \
         && echo $process completed || echo $process returned $?;
elif [ $process = build ]; then build \
         && echo $process completed || echo $process returned $?;
elif [ $process = plan ]; then plan \
         && echo $process completed || echo $process returned $?;
elif [ $process = destroy ]; then destroy \
         && echo $process completed || echo $process returned $?;
elif [ $process = show ]; then show \
         && echo $process completed || echo $process returned $?;
else echo Exiting - Unknown process;
fi
